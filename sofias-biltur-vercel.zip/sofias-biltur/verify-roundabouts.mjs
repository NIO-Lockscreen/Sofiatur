import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import * as T from './dist/vendor/three.js';
import {roundaboutChoices} from './dist/roundabouts.js';
import {createFreeDrive} from './dist/free-drive.js';
const data=JSON.parse(fs.readFileSync('dist/map.json','utf8')),els=new Map();let callbacks=[],now=0;
const canvasContext=new Proxy({},{get:()=>()=>{}});
const element=id=>{if(!els.has(id))els.set(id,{hidden:false,textContent:'',style:{},children:[],classList:{add(){},remove(){},toggle(){}},setAttribute(){},append(...v){this.children.push(...v)},replaceChildren(){this.children=[]},addEventListener(){},getContext(){return canvasContext}});return els.get(id);};
const env={T,roundaboutChoices,console,performance:{now:()=>now},document:{getElementById:element,createElement:()=>element(Symbol()),body:element('body'),addEventListener(){}},window:{addEventListener(){}},setTimeout:()=>0,clearTimeout(){},requestAnimationFrame:cb=>callbacks.push(cb),fetch:async()=>({ok:true,json:async()=>data}),createWorld:()=>({height:()=>160,update(){},resetCamera(){},setTurnArrow(){}})};
env.createFreeDrive=createFreeDrive;
const ctx=vm.createContext(env);
const code=fs.readFileSync('dist/game.js','utf8').replace(/^import .*?;\n/gm,'');
const init=vm.runInContext(`(async()=>{${code}\n globalThis.test={read:gameState,enter(e){current=e.to;previous=e.from;active=null;paused=false;state='decision';maxKmh=200;position.copy(point(current));heading.copy(endDirection(e,false));showDecision();},getActive:()=>active};})()`,ctx);
function frame(){now+=45;const q=callbacks.splice(0);q.forEach(cb=>cb(now));}
for(let i=0;i<12;i++){await Promise.resolve();frame();}await init;
const ringNodes=new Set(data.edges.filter(e=>e.roundabout).map(e=>e.from));
const entries=data.edges.filter(e=>!e.roundabout&&ringNodes.has(e.to)&&!ringNodes.has(e.from));
let tested=0;
for(const entry of entries){
 env.test.enter(entry);const exits=env.test.read().choices;
 assert.ok(exits.length>=2,'Every entrance offers exits');
 assert.equal(element('worldArrows').children.length,exits.length,'Every exit has a touch button, including shared directions');
 for(let i=0;i<exits.length;i++){
  env.test.enter(entry);const before=env.test.read();element('worldArrows').children[i].onclick();assert.equal(element('undoRoundabout').hidden,false);
  const plan=env.test.getActive().e;
  assert.ok(plan.roundaboutPlan);assert.ok(exits.some(e=>e.id===plan.id&&e.exitNumber===plan.exitNumber));
  for(let j=1;j<plan.segments.length;j++)assert.equal(plan.segments[j-1].to,plan.segments[j].from,'Continuous directed path');
  const control=env.test.getActive();let frames=0;
  element('pause').onclick();const old=env.test.read().travelledMetres;for(let j=0;j<10;j++)frame();assert.equal(env.test.read().travelledMetres,old);element('pause').onclick();
  while(env.test.getActive()===control&&frames++<15000){frame();if(env.test.getActive()===control)assert.equal(env.test.read().state,'driving','No intermediate stop inside circle');}
  assert.ok(frames<15000,'Reaches selected exit');assert.equal(env.test.read().currentNode,plan.to,'Arrives at selected road');element('undoRoundabout').onclick();assert.equal(env.test.read().currentNode,entry.to);assert.equal(env.test.read().state,'decision');assert.equal(env.test.read().travelledMetres,before.travelledMetres);assert.equal(element('worldArrows').children.length,exits.length);assert.equal(element('undoRoundabout').hidden,true);element('worldArrows').children[i].onclick();for(let j=0;j<8;j++)frame();element('undoRoundabout').onclick();assert.equal(env.test.read().currentNode,entry.to);assert.equal(env.test.read().state,'decision');tested++;
 }
}
console.log(`Roundabouts: ${tested} exits from ${entries.length} entrances passed; touch, pause, directed route and automatic traversal and undo verified.`);
